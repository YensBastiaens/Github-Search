let form = document.getElementById('form');



form.addEventListener('submit', function (e) {
    e.preventDefault();


    let input = document.getElementById('input').value;


    fetch('https://api.github.com/users/' + input)
        .then((result) => result.json())
        .then((data) => {
            console.log(data)

            document.getElementById('photo').innerHTML = `<a target="_blank" href="https://www.github.com/${input}">  <img src="${data.avatar_url}"></a>`

            document.getElementById('name').innerHTML = `<p><a target="_blank" href="https://www.github.com/${input}">${data.name}</p>`

            document.getElementById('username').innerHTML = `<p"><a target="_blank" href="https://www.github.com/${input}">${data.login}</p>`


            const date = new Date(data.created_at);
            const day = date.getDay();
            const months = ['Jan', 'Feb', 'Ma', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            const month = date.getMonth();
            const month_name = months[month]
            const year = date.getFullYear();

            document.getElementById('date_joined').innerHTML = `<p>Joined ${day} ${month_name} ${year}</p>`

            document.getElementById('bio').innerHTML = `<p>${data.bio}</p>`

            document.getElementById('repos').innerHTML = `<p>Repos</p><strong>${data.public_repos}</strong>`

            document.getElementById('followers').innerHTML = `<p>Followers</p><strong>${data.followers}</strong>`

            document.getElementById('following').innerHTML = `<p>Following</p> <strong>${data.following}</strong>`


            if (data.blog == null) {
                data.blog = 'not available'
            }
            document.getElementById('location').innerHTML = `<p><i class='fa fa-map-marker'> </i> ${data.location}</p>`

            if (data.twitter_username == null) {
                data.twitter_username = 'not available'
            }
            document.getElementById('twitter').innerHTML = `<p><i class='fa fa-twitter'></i> <a target="_blank" href="https://twitter.com/${data.twitter_username}">${data.twitter_username}</a></p>`

            if (data.blog == null) {
                data.blog = 'not available'
            }
            document.getElementById('website').innerHTML = `<p><i class='fa fa-link'></i> 
            <a target="_blank" href="https://${data.blog}">${data.blog}</a></p>`

            if (data.company == null) {
                data.company = 'not available'
            }
            document.getElementById('company').innerHTML = `<p><i class='fa fa-building'></i>
             ${data.company}</p>`

            function changeBackground(color) {
                document.getElementsByClassNamer('results').style.backgroundColor = 'red';
            }
            document.getElementById('input').onclick = changeBackground;
        });

});